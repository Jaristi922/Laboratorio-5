# Catalog Frontend (React)

Frontend del laboratorio Full Stack (Spring Boot + ReactJS). Consume la API en `http://localhost:8080/api/books`.

```bash
npm install
npm start      # abre http://localhost:3000
```

Estructura: `src/services/BookService.js` (axios), `src/components/BookList.jsx`, `src/components/BookForm.jsx`, `src/App.jsx`.
Funciones: listar, crear, editar, eliminar y buscar por nombre. Requiere el backend corriendo en el puerto 8080.
