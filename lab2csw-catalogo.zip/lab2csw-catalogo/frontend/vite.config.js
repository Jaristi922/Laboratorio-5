import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// El laboratorio indica que el frontend corre en http://localhost:3000 (origen permitido por CORS en Spring Boot)
export default defineConfig({
  plugins: [react()],
  server: { port: 3000, strictPort: true },
});
