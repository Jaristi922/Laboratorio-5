import React, { useCallback, useEffect, useState } from 'react';
import BookService from './services/BookService.js';
import BookList from './components/BookList.jsx';
import BookForm from './components/BookForm.jsx';

export default function App() {
  const [books, setBooks] = useState([]);
  const [query, setQuery] = useState('');
  const [editingBook, setEditingBook] = useState(null);
  const [message, setMessage] = useState(null); // { type: 'success' | 'danger', text }

  const notify = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 4000);
  };

  const loadBooks = useCallback(async () => {
    try {
      setBooks(await BookService.getAll());
    } catch {
      notify('danger', 'No se pudo conectar con el backend (http://localhost:8080).');
    }
  }, []);

  useEffect(() => {
    loadBooks();
  }, [loadBooks]);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) return loadBooks();
    try {
      setBooks(await BookService.search(query.trim()));
    } catch {
      notify('danger', 'Error al buscar libros.');
    }
  };

  const handleSubmit = async (book) => {
    try {
      if (editingBook) {
        await BookService.update(editingBook.id, book);
        notify('success', `Libro "${book.name}" actualizado correctamente.`);
        setEditingBook(null);
      } else {
        await BookService.create(book);
        notify('success', `Libro "${book.name}" creado correctamente.`);
      }
      setQuery('');
      loadBooks();
    } catch {
      notify('danger', 'No se pudo guardar el libro.');
    }
  };

  const handleDelete = async (book) => {
    if (!window.confirm(`¿Eliminar el libro "${book.name}"?`)) return;
    try {
      await BookService.remove(book.id);
      notify('success', `Libro "${book.name}" eliminado correctamente.`);
      if (editingBook?.id === book.id) setEditingBook(null);
      loadBooks();
    } catch {
      notify('danger', 'No se pudo eliminar el libro.');
    }
  };

  return (
    <div className="container-fluid p-4">
      <h2 className="mb-3"> 📚 Gestion de Libros 📖 </h2>

      {message && <div className={`alert alert-${message.type} py-2`}>{message.text}</div>}

      <form onSubmit={handleSearch} className="d-flex gap-2" style={{ maxWidth: 360 }}>
        <input className="form-control form-control-sm" placeholder="Search by name" value={query} onChange={(e) => setQuery(e.target.value)} />
        <button className="btn btn-sm btn-search" type="submit">🔍 Search</button>
        {query && (
            <button className="btn btn-sm btn-outline-secondary" type="button" onClick={() => { setQuery(''); loadBooks(); }}>
              Clear
            </button>
        )}
      </form>

      <h6 className="mt-3 mb-0">{editingBook ? `Edit Book #${editingBook.id}` : 'Add Book'}</h6>
      <BookForm editingBook={editingBook} onSubmit={handleSubmit} onCancel={() => setEditingBook(null)} />

      <BookList books={books} onEdit={setEditingBook} onDelete={handleDelete} />
    </div>
  );
}
