import React from 'react';

export default function BookList({ books, onEdit, onDelete }) {
  return (
    <div className="card shadow-sm mt-4">
      <div className="card-body">
        <h4 className="card-title mb-3">📚 Catalogo de Libros</h4>
        <table className="table table-bordered table-hover align-middle mb-0">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>ISBN</th>
              <th>Author</th>
              <th>Publish Date</th>
              <th>Price</th>
              <th>Type</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {books.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center text-muted">
                  No books found
                </td>
              </tr>
            ) : (
              books.map((b) => (
                <tr key={b.id}>
                  <td>{b.id}</td>
                  <td>{b.name}</td>
                  <td>{b.isbnNumber}</td>
                  <td>{b.author}</td>
                  <td>{b.publishDate}</td>
                  <td>{b.price}</td>
                  <td>{b.type}</td>
                  <td className="text-nowrap">
                    <button className="btn btn-sm btn-edit me-1" onClick={() => onEdit(b)}>
                      ✏️ Edit
                    </button>
                    <button className="btn btn-sm btn-delete" onClick={() => onDelete(b)}>
                      🗑️ Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
