import React, { useEffect, useState } from 'react';

const EMPTY = { name: '', isbnNumber: '', author: '', publishDate: '', price: '', type: 'HARDCOVER' };

// Formulario para crear (POST) o editar (PUT) un libro.
export default function BookForm({ editingBook, onSubmit, onCancel }) {
  const [form, setForm] = useState(EMPTY);

  useEffect(() => {
    setForm(editingBook ? { ...EMPTY, ...editingBook, price: editingBook.price ?? '' } : EMPTY);
  }, [editingBook]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ ...form, price: form.price === '' ? null : parseFloat(form.price) });
    if (!editingBook) setForm(EMPTY);
  };

  return (
    <form onSubmit={handleSubmit} className="row g-2 align-items-end mt-2">
      <div className="col-md-2">
        <input className="form-control form-control-sm" name="name" placeholder="Book Name" value={form.name} onChange={handleChange} required />
      </div>
      <div className="col-md-2">
        <input className="form-control form-control-sm" name="isbnNumber" placeholder="ISBN" value={form.isbnNumber} onChange={handleChange} required />
      </div>
      <div className="col-md-2">
        <input className="form-control form-control-sm" name="author" placeholder="Author" value={form.author} onChange={handleChange} required />
      </div>
      <div className="col-md-2">
        <input type="date" className="form-control form-control-sm" name="publishDate" value={form.publishDate} onChange={handleChange} required />
      </div>
      <div className="col-md-1">
        <input type="number" step="0.01" min="0" className="form-control form-control-sm" name="price" placeholder="Price" value={form.price} onChange={handleChange} required />
      </div>
      <div className="col-md-1">
        <select className="form-select form-select-sm" name="type" value={form.type} onChange={handleChange}>
          <option value="EBOOK">EBOOK</option>
          <option value="SOFTCOPY">SOFTCOPY</option>
          <option value="HARDCOVER">HARDCOVER</option>
        </select>
      </div>
      <div className="col-md-2 text-nowrap">
          <button type="submit" className="btn btn-sm btn-add">
              {editingBook ? '💾 Update Book' : '➕ Add Book'}
          </button>
          {editingBook && (
              <button type="button" className="btn btn-sm btn-outline-secondary ms-1" onClick={onCancel}>
                  Cancel
              </button>
          )}
      </div>
    </form>
  );
}
