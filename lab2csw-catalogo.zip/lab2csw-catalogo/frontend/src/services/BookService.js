import axios from 'axios';

const API_URL = 'http://localhost:8080/api/books';

const BookService = {
  getAll: () => axios.get(API_URL).then((r) => r.data),

  getById: (id) => axios.get(`${API_URL}/${id}`).then((r) => r.data),

  // El backend responde 204 (sin cuerpo) cuando no hay coincidencias
  search: (name) =>
    axios.get(`${API_URL}/search`, { params: { name } }).then((r) => (r.status === 204 ? [] : r.data)),

  create: (book) => axios.post(API_URL, book).then((r) => r.data),

  update: (id, book) => axios.put(`${API_URL}/${id}`, book).then((r) => r.data),

  remove: (id) => axios.delete(`${API_URL}/${id}`),
};

export default BookService;
