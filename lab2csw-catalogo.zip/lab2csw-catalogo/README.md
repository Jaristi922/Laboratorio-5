# Laboratorio Full Stack: Spring Boot + ReactJS

- `backend/`  → API REST (Spring Boot, JPA, H2). Puerto 8080.
- `frontend/` → Interfaz React (Vite, Axios, Bootstrap). Puerto 3000.

## Ejecución (dos terminales)
1. Backend:  `cd backend && ./mvnw spring-boot:run`   (Swagger: http://localhost:8080/swagger-ui.html)
2. Frontend: `cd frontend && npm install && npm start` (http://localhost:3000)

El frontend llama a `http://localhost:8080/api/books` (ver `frontend/src/services/BookService.js`)
y el backend permite ese origen en `backend/src/main/java/com/tdea/lab2csw/config/ConfigCors.java`.
