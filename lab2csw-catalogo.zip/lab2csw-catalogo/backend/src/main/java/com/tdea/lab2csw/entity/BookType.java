package com.tdea.lab2csw.entity;

public enum BookType {
    EBOOK,SOFTCOPY,HARDCOVER
}
