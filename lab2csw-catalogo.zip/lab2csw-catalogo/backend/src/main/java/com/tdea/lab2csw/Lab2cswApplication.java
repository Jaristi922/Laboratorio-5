package com.tdea.lab2csw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab2cswApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab2cswApplication.class, args);
	}

}
