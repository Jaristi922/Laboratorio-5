package com.tdea.lab2csw.controller;

import com.tdea.lab2csw.entity.Book;
import com.tdea.lab2csw.service.BookService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping(value = "/api/books",
         produces = MediaType.APPLICATION_JSON_VALUE)
@Tag(name = "Book API"
,description = "Sistema de Gestion de Libros")
public class BookController {
    //1. Recursos HTTP --> URI (Id de Recursos Uniformes)
    //2. Metodos HTTP (GET, POST, PUT, DELETE, Connect, Trace, Head)
    //3. Formato de Representación --> MIME Types
    // JSON --> application/json
    //XML --> application/xml
    //text plain ---> text/plain
    //video --> video/mp4
    //html --> text/html
    //4. Documentación del servicio OpenAPI o SWAGGER o RAML
    // 5.Status Codes
    // 1XX --> Information
    // 2XX --> Success
    //3XX --> redirect
    //4XX --> Errores Client
    //5XX --> errores server
    /// http://localhost:8080/api/books GET (findAll())

    @Autowired
    private BookService bookService;

    //GET
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookService.findAll());
    }
    //http://localhost:8080/api/books/1234545
    //http://localhost:8080/api/books/9988777

    /// http://localhost:8080/api/books/7377373
    //http://localhost:8080/api/books/{id}
    //Buscar por un ID
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") Long id) {
        try {
            Book book = bookService.findById(id);
            return ResponseEntity.ok(book); // 200 OK
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); //404 Nof Found

        }
    }

    //CREATE
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Book> addBook(@Valid @RequestBody Book book) {
        Book bookSaved = bookService.save(book);
        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(bookSaved.getId())
                .toUri();
        return ResponseEntity.created(location).body(bookSaved);// 201 CREATED

    }

    //Actualizar
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Book> updateBook(@PathVariable("id") Long id,
                                           @Valid @RequestBody Book book) {
        try {
            //validar si el libro existe
            bookService.findById(id);
            Book updatedBook = bookService.update(id, book);
            return ResponseEntity.ok(updatedBook);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }

    }

    //Borrar
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable("id") Long id) {
        try{
            bookService.findById(id);
            bookService.deleteById(id);
            return ResponseEntity.noContent().build(); //204 No Content

        }catch (Exception e) {
            return ResponseEntity.notFound().build();
        }

    }

@GetMapping("/search")
    public ResponseEntity<List<Book>> searchBook(@RequestParam String name) {
       List<Book> books = bookService.findByName(name);
        if(books.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(books);
}



}
